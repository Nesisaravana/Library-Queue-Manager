# 📚 Library Queue Manager

A Java console-based project to manage queues for unavailable library books.

## ✨ Features
- Add users to queue when a book is unavailable
- Automatically serve next user when book returns
- Simple console UI
- Can be extended to use MySQL with JDBC

## 🧰 Tech Used
- Java (JDK 17+)
- MySQL (optional for expansion)

## 🚀 How to Run
1. Clone the repo:
   ```bash
   git clone https://github.com/<your-username>/LibraryQueueManager.git
   ```
2. Open in any IDE (IntelliJ / Eclipse / VSCode)
3. Run `LibraryQueueManager.java`

## 💡 Future Enhancements
- GUI using JavaFX or Swing
- SMS/Email notifications
- Real-time MySQL integration
