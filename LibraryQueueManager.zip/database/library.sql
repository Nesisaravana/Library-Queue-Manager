CREATE DATABASE librarydb;
USE librarydb;

CREATE TABLE books (
  id INT PRIMARY KEY,
  title VARCHAR(100),
  available BOOLEAN
);

INSERT INTO books VALUES (101, 'Operating Systems', FALSE), (102, 'Java Programming', TRUE);