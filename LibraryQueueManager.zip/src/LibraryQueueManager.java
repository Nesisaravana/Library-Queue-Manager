import java.util.Scanner;

public class LibraryQueueManager {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        QueueManager manager = new QueueManager();

        User u1 = new User(1, "Nesihaa");
        User u2 = new User(2, "Anitha");
        User u3 = new User(3, "Priya");

        Book b1 = new Book(101, "Operating Systems", false);
        Book b2 = new Book(102, "Java Programming", true);

        System.out.println("\uD83D\uDCDA Welcome to Library Queue Manager \uD83D\uDCDA");

        while (true) {
            System.out.println("\n1. Add user to queue\n2. Serve next user\n3. Show queue\n4. Exit");
            System.out.print("Enter choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    System.out.println("Enter Book ID (101/102): ");
                    int bid = sc.nextInt();
                    System.out.println("Enter User ID (1/2/3): ");
                    int uid = sc.nextInt();
                    User u = uid == 1 ? u1 : uid == 2 ? u2 : u3;
                    manager.addToQueue(bid, u);
                    break;

                case 2:
                    System.out.println("Enter Book ID to serve next: ");
                    manager.serveNextUser(sc.nextInt());
                    break;

                case 3:
                    System.out.println("Enter Book ID to view queue: ");
                    manager.showQueue(sc.nextInt());
                    break;

                case 4:
                    System.out.println("Exiting...");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid option!");
            }
        }
    }
}