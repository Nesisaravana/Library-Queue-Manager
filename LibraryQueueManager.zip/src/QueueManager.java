import java.util.*;

public class QueueManager {
    private Map<Integer, Queue<User>> bookQueues = new HashMap<>();

    public void addToQueue(int bookId, User user) {
        bookQueues.putIfAbsent(bookId, new LinkedList<>());
        Queue<User> queue = bookQueues.get(bookId);
        queue.add(user);
        System.out.println(user.getName() + " added to the queue for book ID " + bookId);
    }

    public void serveNextUser(int bookId) {
        Queue<User> queue = bookQueues.get(bookId);
        if (queue == null || queue.isEmpty()) {
            System.out.println("No users in queue for book ID " + bookId);
            return;
        }
        User next = queue.poll();
        System.out.println("Book ID " + bookId + " is now available for " + next.getName());
    }

    public void showQueue(int bookId) {
        Queue<User> queue = bookQueues.get(bookId);
        if (queue == null || queue.isEmpty()) {
            System.out.println("No queue for book ID " + bookId);
            return;
        }
        System.out.println("Queue for book ID " + bookId + ":");
        for (User u : queue)
            System.out.println(" - " + u.getName());
    }
}